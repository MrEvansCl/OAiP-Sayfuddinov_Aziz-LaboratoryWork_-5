﻿using System;

namespace laba5oaip
{

    public class Fraction
    {
        private int first; 
        private int second; 
        public int First
        {
            get { return this.first; }
            set { this.first = value; }
        }

        public int Second
        {
            get { return this.second; }
            set { this.second = value; }
        }
        public Fraction(int first, int second)
        {
            this.first = first;
            this.second = second;
        }

        public Fraction() : this(0, 1) { }
        public void Read()
        {
            int inputVal;

            Console.Write("Введите числитель (first, целое положительное): ");
            while (true)
            {

                if (int.TryParse(Console.ReadLine(), out inputVal))
                {
                    if (inputVal > 0)
                    {
                        this.First = inputVal;
                        break;
                    }
                }
                Console.Write("Ошибка! Введите целое пложительное число: ");
            }
            Console.Write("Введите знаменатель (second, целое положительное): ");
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out inputVal))
                {
                    if (inputVal > 0)
                    {
                        this.Second = inputVal;
                        break;
                    }
                }
                Console.Write("Ошибка! Введите целое положительное число: ");
            }
        }

        public void Display()
        {
            Console.WriteLine($"{this.First}/{this.Second}");
        }

        public void nesokr()
        {
            if (this.First == 0)
            {
                this.Second = 1; 
                return;
            }
            int common = GCD(this.First, this.Second);
            this.First /= common;
            this.Second /= common;
        }

        private int GCD(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);

            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
    }

    class task1
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("Приведение дроби к несократимому виду\n");
            Fraction frac = new Fraction();
            frac.Read();
            Console.Write("\nИсходная дробь: ");
            frac.Display();
            frac.nesokr();
            Console.Write("Несократимая дробь: ");
            frac.Display();
            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}