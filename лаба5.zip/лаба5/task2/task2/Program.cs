﻿namespace task2
{
    public class Vector3D
    {
        private double x;
        private double y;
        private double z;
        public double X
        {
            get { return this.x; }
            set { this.x = value; }
        }

        public double Y
        {
            get { return this.y; }
            set { this.y = value; }
        }

        public double Z
        {
            get { return this.z; }
            set { this.z = value; }
        }

        public Vector3D(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public Vector3D() : this(0, 0, 0) { }

        public double Length()
        {
            return Math.Sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
        }

        public static Vector3D operator +(Vector3D v1, Vector3D v2)
        {
            return new Vector3D(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
        }

        public static Vector3D operator -(Vector3D v1, Vector3D v2)
        {
            return new Vector3D(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
        }

        public static Vector3D operator *(Vector3D v, double scalar)
        {
            return new Vector3D(v.x * scalar, v.y * scalar, v.z * scalar);
        }

        public double DotProduct(Vector3D other)
        {
            return this.x * other.x + this.y * other.y + this.z * other.z;
        }

        public bool Equals(Vector3D other)
        {
            if (other == null) return false;
            return this.x == other.x && this.y == other.y && this.z == other.z;
        }

        public int CompareLength(Vector3D other)
        {
            if (other == null) throw new ArgumentNullException(nameof(other));
            double len1 = this.Length();
            double len2 = other.Length();

            if (len1 > len2) return 1;
            if (len1 < len2) return -1;
            return 0;
        }

        public override string ToString()
        {
            return $"({this.x:F2}, {this.y:F2}, {this.z:F2})";
        }
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("Задание 2-2: Класс Vector3D\n");

            Vector3D v1 = new Vector3D(1, 2, 3);
            Vector3D v2 = new Vector3D(4, 5, 6);

            Console.WriteLine($"v1 = {v1}");
            Console.WriteLine($"v2 = {v2}");

            Console.WriteLine($"\n Длина v1: {v1.Length():F3}");
            Console.WriteLine($"Длина v2: {v2.Length():F3}");

            Vector3D sum = v1 + v2;
            Console.WriteLine($"\nСложение: v1 + v2 = {sum}");

            Vector3D diff = v1 - v2;
            Console.WriteLine($"Вычитание: v1 - v2 = {diff}");

            double scalar = 2.5;
            Vector3D scaled = v1 * scalar;
            Console.WriteLine($"Умножение v1 на {scalar}: {scaled}");

            double dot = v1.DotProduct(v2);
            Console.WriteLine($"\nСкалярное произведение v1·v2 = {dot}");

            bool areEqual = v1.Equals(v2);
            Console.WriteLine($"Векторы равны? {areEqual}");

            int comp = v1.CompareLength(v2);
            string res = comp > 0 ? "больше" : comp < 0 ? "меньше" : "равна";
            Console.WriteLine($"Длина v1 {res} длины v2");
        }
    }
}